(function() {
  function fn(a) {
    return void 0===a?'undefined':'not undefined'
  }
})();
