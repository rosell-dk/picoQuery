(function(u) {
  function fn(a) {
    return u===a?'undefined':'not undefined'
  }
})();
